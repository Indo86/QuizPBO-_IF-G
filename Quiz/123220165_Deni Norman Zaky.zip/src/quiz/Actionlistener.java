
package quiz;

import java.awt.event.ActionEvent;


interface Actionlistener {
    public void actionPerformed(ActionEvent e);
}
